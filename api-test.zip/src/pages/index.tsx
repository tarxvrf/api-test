import React from 'react'
import Sidebar from './sidebar'

function index() {
  return (
    <div><Sidebar/></div>
  )
}

export default index