import React from 'react'

function Sidebar() {
  return (
    <div className="drawer">
    <div className='min-h-screen w-64 bg-base-200 '>

    </div>
    
  </div>
  )
}

export default Sidebar